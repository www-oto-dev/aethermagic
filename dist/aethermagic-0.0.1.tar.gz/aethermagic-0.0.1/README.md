# Aether Magic - Communications between microservices over MQTT



